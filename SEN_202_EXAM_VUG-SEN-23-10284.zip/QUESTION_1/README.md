
# SEN 202 EXAM - VUG/SEN/23/10284

## Student Information
- **Full Name:** Justin Orna Justin  
- **Matric Number:** VUG/SEN/23/10284  
- **GitHub Profile:** [Justin's GitHub](https://github.com/your-github-username)

## Description
This is the submission for SEN 202 Software Construction Practical Exam. The project includes:
- Django API for managing company staff
- Inheritance & Abstraction via StaffBase
- Encapsulation with role-based serialization
- Admin interface with sample data

## Setup Instructions
```bash
# Create virtual environment
python -m venv justin_sen202_env
source justin_sen202_env/bin/activate  # Use 'justin_sen202_env\Scripts\activate' on Windows

# Install dependencies
pip install -r requirements.txt

# Run migrations
python manage.py makemigrations
python manage.py migrate

# Create superuser
python manage.py createsuperuser
```
