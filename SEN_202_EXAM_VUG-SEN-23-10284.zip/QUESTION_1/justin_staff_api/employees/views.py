from rest_framework import viewsets
from .models import Manager, Intern
from .serializers import ManagerSerializer, InternSerializer

class StaffBaseViewSet(viewsets.ModelViewSet):
    pass

class ManagerViewSet(StaffBaseViewSet):
    queryset = Manager.objects.all()
    serializer_class = ManagerSerializer

class InternViewSet(StaffBaseViewSet):
    queryset = Intern.objects.all()
    serializer_class = InternSerializer