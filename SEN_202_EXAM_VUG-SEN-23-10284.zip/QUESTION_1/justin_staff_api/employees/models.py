from django.db import models

class StaffBase(models.Model):
    name = models.CharField(max_length=100)
    department = models.CharField(max_length=100)
    has_company_card = models.BooleanField(default=False)

    class Meta:
        abstract = True

    def get_role(self):
        return self.__class__.__name__


class Manager(StaffBase):
    role = models.CharField(max_length=100)
    mentor = models.ForeignKey('self', null=True, blank=True, on_delete=models.SET_NULL)

    def __str__(self):
        return f"Manager: {self.name}"


class Intern(StaffBase):
    internship_end = models.DateField()

    def __str__(self):
        return f"Intern: {self.name}"


class Address(models.Model):
    street = models.CharField(max_length=100)
    city = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    manager = models.ForeignKey(Manager, null=True, blank=True, on_delete=models.CASCADE)
    intern = models.ForeignKey(Intern, null=True, blank=True, on_delete=models.CASCADE)